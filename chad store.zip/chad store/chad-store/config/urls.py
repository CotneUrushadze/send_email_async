"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path, include, re_path
from django.conf.urls.static import static
from django.conf import settings

from rest_framework import permissions
from drf_yasg import openapi 
from drf_yasg.views import get_schema_view

from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView


schema_view = get_schema_view(
    openapi.Info(
        title='API form E-Commece platform',
        default_version='v1',
        description='E-Commerce project for mziuri'
    ),
    public=True,
    permission_classes=[permissions.AllowAny]
)



urlpatterns = [
    path("admin/", admin.site.urls),
    
    path("", include('products.urls')),
    path("", include('categories.urls')),
    path("", include('users.urls')),
    
    path("swagger/", schema_view.with_ui('swagger', cache_timeout=0), name='swagger-ui'),
    path("redoc/", schema_view.with_ui('redoc', cache_timeout=0), name='redoc-ui'),
    
    path('login/', TokenObtainPairView.as_view(), name='login'),
    path('login/refresh/', TokenRefreshView.as_view(), name='login_refresh'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
